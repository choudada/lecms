<?php
defined('ROOT_PATH') or exit;

$arr[] = array('name'=>lang('f_links'), 'url'=>'index.php?links-index', 'icon'=>'fa fa-link');
