<?php
defined('ROOT_PATH') or exit;

$menu['menuInfo']['plugin']['child'][] = array('title' => lang('f_links'), 'href' => 'index.php?links-index', 'icon' => 'fa fa-link', 'target' => '_self');