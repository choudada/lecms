<?php
return array(
	'name' => 'SdEditor 编辑器',	// 插件名
	'brief' => '基于Jquery开发的轻量化、所见即所得的web富文本编辑器，体积小、安全性高、同时支持一个页面多次调用，支持移动端自适应使用。',
	'version' => '1.0.0',			// 插件版本
	'cms_version' => '3.0.0',		// 插件支持的程序版本
	'update' => '2022-12-16',		// 插件最近更新
	'author' => '大大的周',				// 插件作者
	'authorurl' => 'https://www.lecms.cc',	// 插件作者主页
    'rand'=>0
);
