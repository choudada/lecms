<?php
return array(
	'name' => 'UEditorMINI 编辑器',	// 插件名
	'brief' => '基于百度 UEditorMINI 编辑器，UM的主要特点就是容量和加载速度上的改变，全版本的代码量为125k，而且放弃了使用传统的iframe模式，采用了div的加载方式，以达到更快的加载速度和零加载失败率。现在UM的第一个使用者是百度贴吧，贴吧每天几亿的pv是对UM各种指标的最好测试平台。',
	'version' => '1.0.0',			// 插件版本
	'cms_version' => '3.0.0',		// 插件支持的程序版本
	'update' => '2022-12-16',		// 插件最近更新
	'author' => '大大的周',				// 插件作者
	'authorurl' => 'https://www.lecms.cc',	// 插件作者主页
);
