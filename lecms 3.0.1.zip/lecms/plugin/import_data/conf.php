<?php
return array(
	'name' => '导入测试数据',	// 插件名
	'brief' => '用于测试LECMS负载，共25961个汉字随机组合出来的文章，生成出来的文章看起来像乱码，其实是博大精深的汉字 ^_^。访问 http://您的网站/index.php?index-import_data 即可开始自动生成内容。',
	'version' => '1.0.0',			// 插件版本
	'cms_version' => '3.0.0',		// 插件支持的 LECMS 版本
	'update' => '2022-12-16',		// 插件最近更新
	'author' => '大大的周',				// 插件作者
	'authorurl' => 'https://www.lecms.cc',	// 插件作者主页
);
