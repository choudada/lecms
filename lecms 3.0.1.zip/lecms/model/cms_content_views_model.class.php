<?php
defined('ROOT_PATH') or exit;

class cms_content_views extends model {
	function __construct() {
		$this->table = '';			// 表名
		$this->pri = array('id');	// 主键
		$this->maxid = 'id';		// 自增字段
	}

    // hook cms_content_views_model_after.php
}
