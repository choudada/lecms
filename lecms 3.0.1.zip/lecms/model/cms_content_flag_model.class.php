<?php
defined('ROOT_PATH') or exit;

class cms_content_flag extends model {
	function __construct() {
		$this->table = '';					// 表名 (可以是 cms_article_flag cms_product_flag cms_photo_flag 等)
		$this->pri = array('flag', 'id');	// 主键
	}

    // 获取内容列表
    public function list_arr($where, $orderby, $orderway, $start, $limit, $total) {
        // 优化大数据量翻页
        if($start > 1000 && $total > 2000 && $start > $total/2) {
            $orderway = -$orderway;
            $newstart = $total-$start-$limit;
            if($newstart < 0) {
                $limit += $newstart;
                $newstart = 0;
            }
            $list_arr = $this->find_fetch($where, array($orderby => $orderway), $newstart, $limit);
            return array_reverse($list_arr, TRUE);
        }else{
            return $this->find_fetch($where, array($orderby => $orderway), $start, $limit);
        }
    }

    // hook cms_content_flag_model_after.php
}
