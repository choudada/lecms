<?php
defined('ROOT_PATH') or exit;

class user extends model {
    private $data = array();		// 防止重复查询

	function __construct() {
		$this->table = 'user';		// 表名
		$this->pri = array('uid');	// 主键
		$this->maxid = 'uid';		// 自增字段
	}

	// 根据用户名获取用户数据
	public function get_user_by_username($username) {
		$data = $this->find_fetch(array('username'=>$username), array(), 0, 1);
		return $data ? current($data) : array();
	}

	// 检查用户名是否合格
	public function check_username(&$username) {
		$username = trim($username);
		if(empty($username)) {
			return lang('username_dis_empty');
		}elseif(utf8::strlen($username) > 16) {
			return lang('username_dis_over_16');
		}elseif(str_replace(array("\t","\r","\n",' ','　',',','，','-','"',"'",'\\','/','&','#','*'), '', $username) != $username) {
			return lang('username_has_illegal_characters');
		}elseif(htmlspecialchars($username) != $username) {
			return lang('username_has_illegal_bracket');
		}

		// hook usre_model_check_username_after.php
		return '';
	}

	// 返回安全的用户名
	public function safe_username(&$username) {
		$username = str_replace(array("\t","\r","\n",' ','　',',','，','-','"',"'",'\\','/','&','#','*'), '', $username);
		$username = htmlspecialchars($username);
	}

	// 检查密码是否合格
	public function check_password(&$password) {
        // hook usre_model_check_password_before.php
		if(empty($password)) {
			return lang('password_dis_empty');
		}elseif(utf8::strlen($password) < 6) {
			return lang('password_dis_less_6');
		}elseif(utf8::strlen($password) > 32) {
			return lang('password_dis_over_32');
		}
		return '';
	}

	// 验证密码是否相等
	public function verify_password($password, $salt, $password_md5) {
		return md5(md5($password).$salt) == $password_md5;
	}

	// 防IP暴力破解
	public function anti_ip_brute($ip) {
        // hook usre_model_anti_ip_brute_before.php
		$password_error = $this->runtime->get('password_error_'.$ip);
		return ($password_error && $password_error >= 8) ? true : false;
	}

	// 根据IP记录密码错误次数
	public function password_error($ip) {
        // hook usre_model_password_error_before.php
		$password_error = (int)$this->runtime->get('password_error_'.$ip);
		$password_error++;
		$this->runtime->set('password_error_'.$ip, $password_error, 450);
	}

	// 格式化后显示给用户
	public function format(&$user, $dateformat = 'Y-m-d H:i') {
		if(!$user) return;
		$user['regdate'] = empty($user['regdate']) ? '0000-00-00 00:00' : date($dateformat, $user['regdate']);
		$user['regip'] = long2ip($user['regip']);
		$user['logindate'] = empty($user['logindate']) ? '0000-00-00 00:00' : date($dateformat, $user['logindate']);
		$user['loginip'] = long2ip($user['loginip']);
		$user['lastdate'] = empty($user['lastdate']) ? '0000-00-00 00:00' : date($dateformat, $user['lastdate']);
		$user['lastip'] = long2ip($user['lastip']);

        //用户个人主页
		$user['user_url'] = $this->cms_content->space_url($user['uid']);

		//用户头像
        $user['avatar'] = $this->cms_content->user_avatar($user['uid']);

        empty($user['author']) && $user['author'] = $user['username'];

		// hook usre_model_format_after.php
	}

    // 获取列表
    public function list_arr($where, $orderby, $orderway, $start, $limit, $total) {
        // 优化大数据量翻页
        if($start > 1000 && $total > 2000 && $start > $total/2) {
            $orderway = -$orderway;
            $newstart = $total-$start-$limit;
            if($newstart < 0) {
                $limit += $newstart;
                $newstart = 0;
            }
            $list_arr = $this->find_fetch($where, array($orderby => $orderway), $newstart, $limit);
            return array_reverse($list_arr, TRUE);
        }else{
            return $this->find_fetch($where, array($orderby => $orderway), $start, $limit);
        }
    }

    //关联删除
    public function xdelete($uid = 0){
        // hook usre_model_xdelete_before.php
        // 内容读取
        $data = $this->read($uid);
        if(empty($data)) return lang('data_no_exists');
        if( $data['uid'] == 1 ) return lang('uid_1_dis_delete');

        $ret = $this->delete($uid);
        if($ret){
            $avatar_file = ROOT_PATH.'upload/avatar/'.$uid.'.png';
            try{
                is_file($avatar_file) && unlink($avatar_file);
            }catch(Exception $e) {}
        }
        return $ret ? '' : lang('delete_failed');
    }

    // hook usre_model_after.php
}
