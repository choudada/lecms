<?php
/**
 * 验证码类
 */
class vcode
{
    private $code;
    private $code_len = 4;
    private $charset = '0123456789'; //设置随机生成因子
    private $width = 120;
    private $height = 30;
    private $img;
    private $font;
    private $fontsize = 16;
    private $fontcolor;
    private $randstring = array('*', '@', '`', '%', '&', '!');
    private $vcodename = 'vcode';

    public function __construct() {
        $this->font = ROOT_PATH.'static/vcode_font/arvo_regular.ttf';
    }

    //生成验证码
    public function get_vcode($vcodename = '',$width = 120, $height = 32) {
        $vcodename && $this->vcodename = $vcodename;
        $this->_code();

        $this->width = min(200, $width ? $width : 120);
        $this->height = min(100, ($height ? $height : 32) - 2);

        $this->_bg();
        $this->_line();
        $this->_font();
        $this->_show();

        return $this->code;
    }

    //生成随机验证码
    private function _code() {
        $code = '';
        $charset_len = strlen($this->charset) - 1;
        for ($i = 0; $i < $this->code_len; $i++) {
            $code .= $this->charset[rand(1, $charset_len)];
        }
        $this->code = trim($code);
        $_SESSION[$this->vcodename] = $code;
    }

    //生成背景
    private function _bg() {
        $this->img = imagecreatetruecolor($this->width, $this->height);
        $color = imagecolorallocate($this->img,255,255,255);
        imagecolortransparent($this->img, $color);
        imagefill($this->img,0,0, $color);
    }

    //生成文字
    private function _font($len = 4) {
        $_x = $this->width / $len;
        $this->fontcolor = imagecolorallocate($this->img,mt_rand(0,180),mt_rand(0,180),mt_rand(0,180));
        for ($i=0; $i<$len; $i++) {
            imagettftext($this->img,$this->fontsize,mt_rand(-30,30),$_x*$i+mt_rand(1,5),$this->height / 1.4,$this->fontcolor,$this->font,$this->code[$i]);
        }
    }

    //生成干扰线条
    private function _line() {
        for ($i=0;$i<5;$i++) {
            $color = imagecolorallocate($this->img,mt_rand(0,180),mt_rand(0,180),mt_rand(0,180));
            imageline(
                $this->img,
                mt_rand(0,$this->width),
                mt_rand(0,$this->height),
                mt_rand(0,$this->width),
                mt_rand(0,$this->height),
                $color
            );
        }
        for ($i=0;$i<30;$i++) {
            $color = imagecolorallocate($this->img,mt_rand(100,255),mt_rand(100,255),mt_rand(100,255));
            imagestring(
                $this->img,
                mt_rand(1,5),
                mt_rand(0,$this->width),
                mt_rand(0,$this->height),
                $this->randstring[rand(0, 5)],
                $color
            );
        }
    }

    //显示
    private function _show() {
        @ob_start();
        @ob_clean(); //关键代码，防止出现'图像因其本身有错无法显示'的问题。
        header('Content-type:image/png');
        imagepng($this->img);
        imagedestroy($this->img);
    }
}