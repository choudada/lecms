<?php
//框架入口文件
defined('FRAMEWORK_PATH') || die('Error Accessing');
//PHP环境检查
version_compare(PHP_VERSION, '5.3.0', '>') || die('require PHP > 5.3.0 !');
// 记录开始运行时间
$_ENV['_start_time'] = microtime(1);
// 记录内存初始使用
define('MEMORY_LIMIT_ON', function_exists('memory_get_usage'));
if(MEMORY_LIMIT_ON) $_ENV['_start_memory'] = memory_get_usage();
//框架版本
define('FRAMEWORK_VERSION', '1.0.0');
defined('MAGIC_QUOTES_GPC') || define('MAGIC_QUOTES_GPC',ini_set("magic_quotes_runtime",0)? true:false);
defined('CONFIG_PATH') || define('CONFIG_PATH', APP_PATH.'config/');	//配置目录
defined('CONTROL_PATH') || define('CONTROL_PATH', APP_PATH.'control/');	//控制器目录
defined('BLOCK_PATH') || define('BLOCK_PATH', APP_PATH.'block/');	//模块目录
defined('MODEL_PATH') || define('MODEL_PATH', APP_PATH.'model/');	//模型目录
defined('VIEW_PATH') || define('VIEW_PATH', ROOT_PATH.'view/');	//视图目录
defined('LOG_PATH') || define('LOG_PATH', ROOT_PATH.'log/');	//日志目录
defined('PLUGIN_PATH') || define('PLUGIN_PATH', APP_PATH.'plugin/');	//插件目录
defined('LANG_PATH') || define('LANG_PATH', APP_PATH.'lang/');	//语言包目录
defined('RUNTIME_PATH') || define('RUNTIME_PATH', ROOT_PATH.'runcache/');	//运行缓存目录
defined('RUNTIME_MODEL') || define('RUNTIME_MODEL', RUNTIME_PATH.APP_NAME.'_model/');	//模型缓存目录
defined('RUNTIME_CONTROL') || define('RUNTIME_CONTROL', RUNTIME_PATH.APP_NAME.'_control/');	//控制器缓存目录
//系统配置文件
include CONFIG_PATH.'config.inc.php';

//调试模式，分三种：0 关闭调试; 1 开启调试; 2 开发调试   注意：开启调试会暴露绝对路径和表前缀
if( defined('F_APP_NAME') ){
    defined('DEBUG') || define('DEBUG', (int)$_ENV['_config']['debug_admin']);
}else{
    defined('DEBUG') || define('DEBUG', (int)$_ENV['_config']['debug']);
}

if(DEBUG) {
	include FRAMEWORK_PATH.'lib/base.func.php';
	include FRAMEWORK_PATH.'lib/core.class.php';
	include FRAMEWORK_PATH.'lib/debug.class.php';
	include FRAMEWORK_PATH.'lib/log.class.php';
	include FRAMEWORK_PATH.'lib/model.class.php';
	include FRAMEWORK_PATH.'lib/view.class.php';
	include FRAMEWORK_PATH.'lib/control.class.php';
	include FRAMEWORK_PATH.'db/db.interface.php';
	include FRAMEWORK_PATH.'db/db_'.$_ENV['_config']['db']['type'].'.class.php';
	include FRAMEWORK_PATH.'cache/cache.interface.php';
	include FRAMEWORK_PATH.'cache/cache_memcache.class.php';
    include FRAMEWORK_PATH.'ext/network/Network__interface.php';
}else{
	$runfile = RUNTIME_PATH.'_runtime.php';
	if(!is_file($runfile)) {
		$s  = trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/base.func.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/core.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/debug.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/log.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/model.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/view.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'lib/control.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'db/db.interface.php'), "<?ph>\r\n");
        $s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'db/db_'.$_ENV['_config']['db']['type'].'.class.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'cache/cache.interface.php'), "<?ph>\r\n");
		$s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'cache/cache_memcache.class.php'), "<?ph>\r\n");
        $s .= trim(php_strip_whitespace(FRAMEWORK_PATH.'ext/network/Network__interface.php'), "<?ph>\r\n");
		$s = str_replace('defined(\'ROOT_PATH\') || exit;', '', $s);
		file_put_contents($runfile, '<?php '.$s);
		unset($s);
	}
	include $runfile;
}
//开启session
session_start();

core::start();
//调试信息
if(DEBUG > 1 && !R('ajax', 'R')) {
	debug::sys_trace();
}