<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台更新内容浏览量控制器 已废弃
 */
defined('ROOT_PATH') or exit;

class views_control extends control{



    // hook views_control_after.php
}
