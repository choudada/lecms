<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台内容页控制器
 */
defined('ROOT_PATH') or exit;

class show_control extends base_control{

    //内容详情
    public function index(){
        // hook show_control_index_before.php

        $_GET['id'] = (int)R('id');
        $_GET['cid'] = (int)R('cid');

        if($this->_cfg['link_show_type'] == 5 && empty($_GET['cid'])){ //ID型URL
            $mid = max(2, R('mid'));
            $table = isset($this->_cfg['table_arr'][$mid]) ? $this->_cfg['table_arr'][$mid] : 'article';

            // 初始模型表名
            $this->cms_content->table = 'cms_'.$table;
            $_show = $this->cms_content->read($_GET['id']);
            if( empty($_show) ) core::error404();

            $_GET['cid'] = $_show['cid'];
            $this->_var = $this->category->get_cache($_GET['cid']);
            (empty($this->_var) || $this->_var['mid'] == 1) && core::error404();
        }else{
            $this->_var = $this->category->get_cache($_GET['cid']);
            (empty($this->_var) || $this->_var['mid'] == 1) && core::error404();

            // 初始模型表名
            $this->cms_content->table = 'cms_'.$this->_var['table'];

            // 读取内容
            $_show = $this->cms_content->read($_GET['id']);
            if(empty($_show['cid']) || $_show['cid'] != $_GET['cid']) core::error404();
        }
        $this->category->format($this->_var);

        // hook show_control_index_center.php

        // SEO 相关
        // hook show_control_index_seo_before.php
        if( empty($_show['seo_title']) ){
            if( empty($this->_var['seo_title']) ){
                $this->_cfg['titles'] = $_show['title'].'-'.$this->_var['name'].'-'.$this->_cfg['webname'];
            }else{
                $this->_cfg['titles'] = $_show['title'].'-'.$this->_var['seo_title'].'-'.$this->_cfg['webname'];
            }
        }else{
            $this->_cfg['titles'] = $_show['seo_title'].'-'.$this->_cfg['webname'];
        }
        if( empty($_show['seo_keywords']) ){
            if( empty($this->_var['seo_keywords']) ){
                $this->_cfg['seo_keywords'] = $this->_cfg['webname'].','.$this->_var['name'].','.$_show['title'];
            }else{
                $this->_cfg['seo_keywords'] = $this->_cfg['webname'].','.$this->_var['seo_keywords'].','.$_show['title'];
            }
        }else{
            $this->_cfg['seo_keywords'] = $_show['seo_keywords'].','.$this->_var['name'].','.$this->_cfg['webname'];
        }
        $this->_cfg['seo_description'] = empty($_show['seo_description']) ? $this->_cfg['webname'].'：'.$_show['intro']: $_show['seo_description'];
        // hook show_control_index_seo_after.php

        $this->assign('cfg', $this->_cfg);
        $this->assign('cfg_var', $this->_var);

        $GLOBALS['run'] = &$this;
        $GLOBALS['_show'] = &$_show;

        // hook show_control_index_after.php
        $_ENV['_theme'] = &$this->_cfg['theme'];
        $this->display($this->_var['show_tpl']);
    }

    // hook show_control_after.php
}