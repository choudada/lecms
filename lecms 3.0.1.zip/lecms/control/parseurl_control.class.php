<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台伪静态路由控制器
 */
defined('ROOT_PATH') or exit;

class parseurl_control extends control{

	public function index() {
		// hook parseurl_control_index_before.php

		if(empty($_GET)) return;

		$cfg = $this->runtime->xget();
		if(!empty($_ENV['_config']['lecms_parseurl']) && !empty($_GET['rewrite'])) {
			$uri = $_GET['rewrite'];
			unset($_GET['rewrite']);
            $url_suffix = $_ENV['_config']['url_suffix'];
            $url_suffix_len = strlen($url_suffix);

            // hook parseurl_control_index_rewrite_before.php

			$cate_arr = array_flip($cfg['cate_arr']);
			// 分类URL未设置后缀的情况
			if(isset($cate_arr[$uri])) {
				$_GET['control'] = 'cate';
				$_GET['action'] = 'index';
				$_GET['cid'] = $cate_arr[$uri];
				return;
			}

			// 分类URL已设置后缀的情况
			$len = strlen($cfg['link_cate_end']);
			if(substr($uri, -$len) == $cfg['link_cate_end']) {
				$newurl = substr($uri, 0, -$len);
				if(isset($cate_arr[$newurl])) {
					$_GET['control'] = 'cate';
					$_GET['action'] = 'index';
					$_GET['cid'] = $cate_arr[$newurl];
					return;
				}
			}

			// 分类URL分页的情况
			if(strpos($uri, $cfg['link_cate_page_pre']) !== FALSE) {
                $len = strlen($cfg['link_cate_page_end']);
				if(substr($uri, -$len) == $cfg['link_cate_page_end']) {
					$newurl = substr($uri, 0, -$len);
					$u_arr = explode($cfg['link_cate_page_pre'], $newurl);
					if(isset($cate_arr[$u_arr[0]])) {
						$_GET['control'] = 'cate';
						$_GET['action'] = 'index';
						$_GET['cid'] = $cate_arr[$u_arr[0]];
						isset($u_arr[1]) && $_GET['page'] = $u_arr[1];
						return;
					}
				}
			}
            // hook parseurl_control_index_link_cate_after.php

            //搜索URL
            if(substr($uri, 0, 7) == 'search/') {
                $_GET['control'] = 'search';
                $_GET['action'] = 'index';

                if(substr($uri, -1) != '/'){
                    $uri .= '/';
                }

                $newurl = substr($uri, 7, -1);
                $u_arr_page = explode('/', $newurl);

                if( isset($u_arr_page[1]) ){
                    $_GET['page'] = (int)$u_arr_page[1];
                    $_GET['keyword'] = $u_arr_page[0];
                }

                $u_arr = explode('_', $u_arr_page[0]);
                $u_arr_count = count($u_arr);
                if($u_arr_count == 1) {
                    $_GET['mid'] = 2;
                    $_GET['keyword'] = $u_arr[0];
                    return ;
                }elseif ($u_arr_count == 2){
                    $_GET['mid'] = (int)$u_arr[0];
                    $_GET['keyword'] = $u_arr[1];
                    return ;
                }
            }

			// 标签URL---------最终统一返回 mid和 name
			$len = strlen($cfg['link_tag_pre']);
			if(substr($uri, 0, $len) == $cfg['link_tag_pre']) {
                $len2 = strlen($cfg['link_tag_end']);
				if(substr($uri, -$len2) == $cfg['link_tag_end']) {
					$newurl = substr($uri, $len, -$len2);

                    $_GET['control'] = 'tag';
                    $_GET['action'] = 'index';

                    if($cfg['link_tag_type'] == 2){ //加密型标签URL
                        $u_arr_page = explode('/', $newurl);
                        isset($u_arr_page[1]) && $_GET['page'] = (int)$u_arr_page[1];

                        $encrypt = $u_arr_page[0];
                        $mid_tagid = decrypt($encrypt);//解密得到 mid_tagid
                        preg_match('#(\d+)\_(\d+)#', $mid_tagid, $mat);
                        if(isset($mat[1]) && isset($mat[2])){
                            $mid = max(2, $mat[1]);
                            $table = isset($cfg['table_arr'][$mid]) ? $cfg['table_arr'][$mid] : 'article';
                            $this->cms_content_tag->table = 'cms_'.$table.'_tag';

                            $tagid = (int)$mat[2];
                            $tags = $this->cms_content_tag->get($tagid);
                            empty($tags) && core::error404();

                            $_GET['mid'] = $mid;
                            $_GET['name'] = $tags['name'];
                            return;
                        }
                    }

					$u_arr = explode('_', $newurl);
                    $u_arr_count = count($u_arr);
                    if($u_arr_count == 1){
                        $mid = $_GET['mid'] = 2;
                        $u_arr_page = explode('/', $newurl);
                        if($cfg['link_tag_type'] == 1){
                            $_GET['tagid'] = (int)$u_arr_page[0];
                        }else{
                            $_GET['name'] = $u_arr_page[0];
                        }
                        isset($u_arr_page[1]) && $_GET['page'] = (int)$u_arr_page[1];
                    }elseif ($u_arr_count == 2){
                        $mid = $_GET['mid'] = (int)$u_arr[0];

                        $u_arr_page = explode('/', $u_arr[1]);
                        if($cfg['link_tag_type'] == 1){
                            $_GET['tagid'] = (int)$u_arr_page[0];
                        }else{
                            $_GET['name'] = $u_arr_page[0];
                        }
                        isset($u_arr_page[1]) && $_GET['page'] = (int)$u_arr_page[1];
                    }

                    //数字型的标签URL
                    if($cfg['link_tag_type'] == 1 && isset($_GET['tagid'])){
                        $table = isset($cfg['table_arr'][$mid]) ? $cfg['table_arr'][$mid] : 'article';
                        $this->cms_content_tag->table = 'cms_'.$table.'_tag';

                        $tags = $this->cms_content_tag->get($_GET['tagid']);
                        empty($tags) && core::error404();

                        $_GET['name'] = $tags['name'];
                    }

                    return;
				}
			}

			// 评论URL
			$len = strlen($cfg['link_comment_pre']);
			if(substr($uri, 0, $len) == $cfg['link_comment_pre']) {
				if(substr($uri, -$url_suffix_len) == $url_suffix) {
					$newurl = substr($uri, $len, -$url_suffix_len);
					$u_arr = explode('_', $newurl);
					if(count($u_arr) > 1) {
						$_GET['control'] = 'comment';
						$_GET['action'] = 'index';
						$_GET['cid'] = $u_arr[0];
						$_GET['id'] = $u_arr[1];
						isset($u_arr[2]) && $_GET['page'] = $u_arr[2];
						return;
					}
				}
			}

			// 首页分页URL (用的少)
			if(substr($uri, 0, 6) == 'index_' && substr($uri, -$url_suffix_len) == $url_suffix) {
				$uri = substr($uri, 6, -$url_suffix_len);
				$u_arr = explode('_', $uri);
				if(count($u_arr) > 1) {
					$_GET['control'] = 'index';
					$_GET['action'] = 'index';
					$_GET['mid'] = $u_arr[0];
					$_GET['page'] = $u_arr[1];
					return;
				}
			}

			// 标签排行页 (用的少)
			if($uri == 'tag_top' || $uri == 'tag_top/') {
				$_GET['control'] = 'tag';
				$_GET['action'] = 'top';
				return;
			}

			//全部标签（用的少）
			if(substr($uri, 0, 7) == 'tag_all'){
                $uri = substr($uri, 0, -$url_suffix_len);
                $u_arr = explode('-', $uri);
                $_GET['control'] = 'tag';
                $_GET['action'] = 'all';
                array_shift($u_arr);
                $num = count($u_arr);
                for($i=0; $i<$num; $i+=2){
                    isset($u_arr[$i+1]) && $_GET[$u_arr[$i]] = $u_arr[$i+1];
                }
                return;
            }

			//属性内容分页（用的少）
            if(substr($uri, 0, 6) == 'flags/'){
                $u_arr = explode('/', $uri);
                if( isset($u_arr[1]) ){
                    $u_arr_1 = explode('_', $u_arr[1]);
                    if( count($u_arr_1) == 2 ){
                        $_GET['control'] = 'flags';
                        $_GET['action'] = 'index';

                        $_GET['mid'] = $u_arr_1[0];
                        $_GET['flag'] = $u_arr_1[1];

                        if(isset($u_arr[2])){
                            $_GET['page'] = max(1, (int)$u_arr[2]);
                        }
                        return;
                    }
                }
            }

            //个人主页
            $len = strlen($cfg['link_space_pre']);
            if(substr($uri, 0, $len) == $cfg['link_space_pre']) {
                $len2 = strlen($cfg['link_space_end']);
                if(substr($uri, -$len2) == $cfg['link_space_end']) {
                    $newurl = substr($uri, $len, -$len2);
                    $u_arr = explode('/', $uri);
                    if(count($u_arr) > 1) {
                        $_GET['control'] = 'space';
                        $_GET['action'] = 'index';
                        $_GET['uid'] = $u_arr[1];
                        $_GET['page'] = isset($u_arr[2]) ? $u_arr[2] : 1;
                    }
                }
            }

            //用户中心相关URL
            if( preg_match('/user-[a-z0-9-]+\.html/', $uri) || preg_match('/my-[a-z0-9-]+\.html/', $uri) ){
                $u_arr = explode('-', substr($uri, 0, -$url_suffix_len));
                if(count($u_arr) > 1) {
                    $_GET['control'] = $u_arr[0];
                    array_shift($u_arr);
                    $_GET['action'] = $u_arr[0];
                    array_shift($u_arr);
                    $num = count($u_arr);
                    for($i=0; $i<$num; $i+=2){
                        isset($u_arr[$i+1]) && $_GET[$u_arr[$i]] = $u_arr[$i+1];
                    }
                    return;
                }
            }

			// hook parseurl_control_index_link_show_before.php

			// 内容页 (最复杂的部分)
			if($cfg['link_show_type'] == 1) { // 1. {cid}/{id} 性能最优
				if(substr($uri, -$url_suffix_len) == $url_suffix) {
					$u_arr = explode('/', substr($uri, 0, -$url_suffix_len));
					if(count($u_arr) > 1) {
						$_GET['control'] = 'show';
						$_GET['action'] = 'index';
						$_GET['cid'] = $u_arr[0];
						$_GET['id'] = $u_arr[1];
						return;
					}
				}
			}elseif($cfg['link_show_type'] == 2) { // 2. {cate_alias}/{id} 性能次优
				if(substr($uri, -$url_suffix_len) == $url_suffix) {
					$u_arr = explode('/', substr($uri, 0, -$url_suffix_len));
					if(count($u_arr) > 1 && isset($cate_arr[$u_arr[0]])) {
						$_GET['control'] = 'show';
						$_GET['action'] = 'index';
						$_GET['cid'] = $cate_arr[$u_arr[0]];
						$_GET['id'] = $u_arr[1];
						return;
					}
				}
			}elseif($cfg['link_show_type'] == 3) { // 3. {alias} 性能一般
				if(substr($uri, -$url_suffix_len) == $url_suffix) {
                    $newurl = substr($uri, 0, -$url_suffix_len);

					// 这处有些特别，如果没有设置别名，将用 cid_id 组合
					preg_match('#(\d+)\_(\d+)#', $newurl, $mat);
					if(isset($mat[2])) {
						$_GET['control'] = 'show';
						$_GET['action'] = 'index';
						$_GET['cid'] = $mat[1];
						$_GET['id'] = $mat[2];
						return;
					}elseif(preg_match('#[a-zA-Z0-9-_]+#', $newurl)) {
						$row = $this->only_alias->get($newurl);
						if(!empty($row)) {
							$_GET['control'] = 'show';
							$_GET['action'] = 'index';
							$_GET['cid'] = $row['cid'];
							$_GET['id'] = $row['id'];
							return;
						}
					}
				}
			}elseif($cfg['link_show_type'] == 4) { // 4. {password} 加密型
                if(substr($uri, -$url_suffix_len) == $url_suffix) {
                    $newurl = substr($uri, 0, -$url_suffix_len);
                    $newurl = decrypt($newurl);//解密得到 cid_id

                    preg_match('#(\d+)\_(\d+)#', $newurl, $mat);
                    if(isset($mat[2])) {
                        $_GET['control'] = 'show';
                        $_GET['action'] = 'index';
                        $_GET['cid'] = $mat[1];
                        $_GET['id'] = $mat[2];
                        return;
                    }else{
                        core::error404();
                    }
                }
            }elseif($cfg['link_show_type'] == 5) { // 5. mid_id ID型
                if(substr($uri, -$url_suffix_len) == $url_suffix) {
                    $newurl = substr($uri, 0, -$url_suffix_len);
                    preg_match('#(\d+)\_(\d+)#', $newurl, $mat);
                    if(isset($mat[2])) {
                        $_GET['control'] = 'show';
                        $_GET['action'] = 'index';
                        $_GET['mid'] = $mat[1];
                        $_GET['id'] = $mat[2];
                        return;
                    }else{
                        $_GET['control'] = 'show';
                        $_GET['action'] = 'index';
                        $_GET['mid'] = 2;
                        $_GET['id'] = $newurl;
                        return;
                    }
                }
            }elseif($cfg['link_show_type'] == 6) { // 6. 分类别名/内容别名 型
                if(substr($uri, -$url_suffix_len) == $url_suffix) {
                    $newurl = substr($uri, 0, -$url_suffix_len);
                    $u_arr = explode('/', $newurl);
                    if( isset($u_arr[1]) ){
                        $cid = $cate_arr[$u_arr[0]];
                        if( empty($cid) ){
                            core::error404();
                        }

                        // 这处有些特别，如果没有设置别名，将用 cid_id 组合
                        preg_match('#(\d+)\_(\d+)#', $u_arr[1], $mat);
                        if(isset($mat[2]) && $mat[1] == $cid) {
                            $_GET['control'] = 'show';
                            $_GET['action'] = 'index';
                            $_GET['cid'] = $mat[1];
                            $_GET['id'] = $mat[2];
                            return;
                        }elseif(preg_match('#[a-zA-Z0-9-_]+#', $u_arr[1])) {
                            $row = $this->only_alias->get($u_arr[1]);
                            if(!empty($row) && $row['cid'] == $cid) {
                                $_GET['control'] = 'show';
                                $_GET['action'] = 'index';
                                $_GET['cid'] = $row['cid'];
                                $_GET['id'] = $row['id'];
                                return;
                            }
                        }
                    }
                }
            }

		}

		// 伪静态时，如果 $uri 有值，但没有解析到相关 $_GET 时，就提示404
		if(empty($_GET) && !empty($uri)) {
			core::error404();
		}

		// 上面都不符合到这里解析
		if(!isset($_GET['control'])) {
			if(isset($_GET['u'])) {
				$u = $_GET['u'];
				unset($_GET['u']);
			}elseif(!empty($_SERVER['PATH_INFO'])) {
				$u = $_SERVER['PATH_INFO'];
			}else{
				$_GET = array();
				$u = $_SERVER["QUERY_STRING"];
			}

			//清除URL后缀
			$url_suffix = C('url_suffix');
			if($url_suffix) {
				$suf_len = strlen($url_suffix);
				if(substr($u, -($suf_len)) == $url_suffix) $u = substr($u, 0, -($suf_len));
			}

			$uarr = explode('-', $u);
			if(count($uarr) < 2) return;

			if(isset($uarr[0])) {
				$_GET['control'] = $uarr[0];
				array_shift($uarr);
			}

			if(isset($uarr[0])) {
				$_GET['action'] = $uarr[0];
				array_shift($uarr);
			}

			//伪静态下 访问动态内容页URL、分类URL、标签URL 则进入404页面
			if(($_GET['control'] == 'show' || $_GET['control'] == 'cate' || $_GET['control'] == 'tag') && $_GET['action'] == 'index'){
                core::error404();
            }

			$num = count($uarr);
			for($i=0; $i<$num; $i+=2){
				isset($uarr[$i+1]) && $_GET[$uarr[$i]] = $uarr[$i+1];
			}
		}
	}
}
