<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台搜索控制器
 */
defined('ROOT_PATH') or exit;

class search_control extends base_control{

	public function index() {
		// hook search_control_index_before.php

		$keyword = urldecode(R('keyword'));
		$keyword = safe_str($keyword);
		
		$this->_cfg['titles'] = $keyword;
		$this->_var['topcid'] = -1;

        $page = (int)R('page','G');
        if( $page > 1){
            $this->_cfg['titles']  .= '-'.lang('page_current', array('page'=>$page));
        }
		
		// hook search_control_index_center.php

		$this->assign('cfg', $this->_cfg);
		$this->assign('cfg_var', $this->_var);
		$this->assign('keyword', $keyword);

		$GLOBALS['run'] = &$this;
		$GLOBALS['keyword'] = &$keyword;

		// hook search_control_index_after.php

		$_ENV['_theme'] = &$this->_cfg['theme'];
		$this->display('search.htm');
	}

    // hook search_control_after.php
}
