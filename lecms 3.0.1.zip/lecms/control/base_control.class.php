<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台共用控制器
 */
defined('ROOT_PATH') or exit;

class base_control extends control{
    public $_cfg = array();	// 全站参数
    public $_var = array();	// 各个模块页参数
    public $_user = array(); // 用户信息
    public $_uid = 0; // 用户ID
    public $_group = array(); // 用户组
    public $_login_url = '';    //登录链接
    public $_register_url = ''; //注册链接
    public $_my_url = '';   //个人中心链接
    public $_logout_url = '';    //退出登录链接
    public $_parseurl = 0;  //是否开启了URL伪静态

    function __construct(){
        $this->_cfg = $this->runtime->xget();
        // hook base_control_construct_before.php

        $form_hash = '';
        $author = (isset($this->_cfg['comment_default_author']) && !empty($this->_cfg['comment_default_author'])) ? $this->_cfg['comment_default_author'] : lang('visitor');
        if( isset($this->_cfg['open_user']) && !empty($this->_cfg['open_user']) ){   //开启了用户功能，获取登录用户信息
            $form_hash = form_hash();

            // hook base_control_get_user_before.php

            $userauth = R($_ENV['_config']['cookie_pre'].'userauth', 'R');
            $admauth = R($_ENV['_config']['cookie_pre'].'admauth', 'R');
            if( empty($userauth) && !empty($admauth) ){
                $userauth = $admauth;
            }
            if($userauth){
                $userauth = str_auth($userauth);
                $arr = explode("\t", $userauth);
                if(count($arr) == 4){
                    $uid      = (int)$arr[0];
                    $username = $arr[1];
                    $password = $arr[2];
                    $groupid  = (int)$arr[3];

                    $this->_user = $this->user->get($uid);
                    $this->_group = $this->user_group->get($this->_user['groupid']);

                    if($this->_user && $this->_group && $this->_user['username'] == $username && $this->_user['groupid'] == $groupid && $this->_user['password'] == $password){
                        $this->user->format($this->_user);
                        $this->_uid = $uid;

                        if( !empty($this->_user['author']) ){
                            $author = $this->_user['author'];
                        }else{
                            $author = $this->_user['username'];
                        }
                    }else{
                        _setcookie('userauth', '', 1);
                    }
                }
            }

            $this->_login_url = $this->cms_content->user_url('login', 'user');
            $this->_register_url = $this->cms_content->user_url('register', 'user');
            $this->_my_url = $this->cms_content->user_url('index', 'my');
            $this->_logout_url = $this->cms_content->user_url('logout', 'my');
        }

        if( !empty($_ENV['_config']['lecms_parseurl']) ){
            $this->_parseurl = 1;
        }

        $GLOBALS['_user'] = &$this->_user;
        $this->assign('author',$author);
        $this->assign('_uid',$this->_uid);
        $this->assign('_user',$this->_user);
        $this->assign('_group',$this->_group);
        $this->assign('form_hash', $form_hash);
        $this->assign('login_url', $this->_login_url);
        $this->assign('register_url', $this->_register_url);
        $this->assign('my_url', $this->_my_url);
        $this->assign('logout_url', $this->_logout_url);
        $this->assign('_parseurl', $this->_parseurl);

        // hook base_control_construct_after.php
    }

    // hook base_control_after.php
}