<?php
/**
 * Author: dadadezhou <379559090@qq.com>
 * Date: 2022-09-24
 * Time: 9:05
 * Description:前台评论相关控制器
 */
defined('ROOT_PATH') or exit;

class comment_control extends base_control{

	public function index() {
		// hook comment_control_index_before.php

		$_GET['cid'] = (int)R('cid');
		$_GET['id'] = (int)R('id');
		$this->_var = $this->category->get_cache($_GET['cid']);
		empty($this->_var) && core::error404();

		// 初始模型表名
		$this->cms_content->table = 'cms_'.$this->_var['table'];

		// 读取内容
		$_show = $this->cms_content->read($_GET['id']);
		if(empty($_show['cid']) || $_show['cid'] != $_GET['cid']) core::error404();

        // hook comment_control_index_seo_before.php

		// SEO 相关
        if( empty($_show['seo_title']) ){
            if( empty($this->_var['seo_title']) ){
                $this->_cfg['titles'] = $_show['title'].'-'.$this->_var['name'].'-'.$this->_cfg['webname'];
            }else{
                $this->_cfg['titles'] = $_show['title'].'-'.$this->_var['seo_title'].'-'.$this->_cfg['webname'];
            }
        }else{
            $this->_cfg['titles'] = $_show['seo_title'].'-'.$this->_cfg['webname'];
        }
        if( empty($_show['seo_keywords']) ){
            if( empty($this->_var['seo_keywords']) ){
                $this->_cfg['seo_keywords'] = $this->_cfg['webname'].','.$this->_var['name'].','.$_show['title'];
            }else{
                $this->_cfg['seo_keywords'] = $this->_cfg['webname'].','.$this->_var['seo_keywords'].','.$_show['title'];
            }
        }else{
            $this->_cfg['seo_keywords'] = $_show['seo_keywords'].','.$this->_var['name'].','.$this->_cfg['webname'];
        }
        $this->_cfg['seo_description'] = empty($_show['seo_description']) ? $this->_cfg['webname'].'：'.$_show['intro']: $_show['seo_description'];

        $page = (int)R('page','G');
        if( $page > 1 ){
            $this->_cfg['titles']  .= '-'.lang('page_current', array('page'=>$page));
        }

        // hook comment_control_index_seo_after.php

		$this->assign('cfg', $this->_cfg);
		$this->assign('cfg_var', $this->_var);

		$GLOBALS['run'] = &$this;
		$GLOBALS['_show'] = &$_show;

		// hook comment_control_index_after.php

		$_ENV['_theme'] = &$this->_cfg['theme'];
		$this->display('comment.htm');
	}

	// 发表评论
	public function post() {
		// hook comment_control_post_before.php

		$cid = (int) R('cid', 'P');
		$id = (int) R('id', 'P');
		$content = htmlspecialchars(trim(R('content', 'P')));
		$author = htmlspecialchars(trim(R('author', 'P')));
		$ip = ip2long(ip());

		if(empty($cid) || empty($id)) $this->message(0, lang('data_error'));
		empty($author) && $this->message(0, lang('comment_author_no_empty'));
		_strlen($author)>20 && $this->message(0, lang('comment_author_than_20'));
		empty($content) && $this->message(0, lang('comment_content_no_empty'));
        _strlen($content)>255 && $this->message(0, lang('comment_content_than_255'));

		// 关闭全站评论
		empty($this->_cfg['open_comment']) && $this->message(0, lang('comments_closed'));

		//未开启游客评论
        if ( empty($this->_cfg['open_no_login_comment']) && empty($this->_uid) ){
            $this->message(0, lang('please_login'));
        }

		//开启评论验证码
		if( isset($this->_cfg['open_comment_vcode']) && !empty($this->_cfg['open_comment_vcode']) ){
            $vcode = htmlspecialchars(trim(R('vcode', 'P')));
            empty($vcode) && $this->message(0, lang('vcode_no_empty'));
            $vcode != _SESSION('vcode') && $this->message(0, lang('vcode_error'));
        }

		$cates = $this->category->get_cache($cid);
		empty($cates) && $this->message(0, lang('data_error'));

		$this->cms_content->table = 'cms_'.$cates['table'];
		$data = $this->cms_content->read($id);

		if(isset($data['iscomment']) && $data['iscomment']){
            $this->message(0, lang('content_comments_closed'));
        }

		$comment_data = array(
            'mid' => $cates['mid'],
            'id' => $id,
            'uid' => $this->_uid,
            'author' => $author,
            'content' => $content,
            'ip' => $ip,
            'dateline' => $_ENV['_time'],
            'reply_commentid' => (int) R('reply_commentid', 'P')
        );
		// hook comment_control_post_create_before.php

		$maxid = $this->cms_content_comment->create($comment_data);
		if(!$maxid) {
			$this->message(0, lang('commented_failed'));
		}

		$comments = $data['comments']+1;

		//更新内容表的评论数
		if(!$this->cms_content->update( array('id'=>$id, 'comments'=>$comments) )) {
			$this->message(0, lang('commented_failed'));
		}

        //更新评论排序表的评论数和最后评论时间
        $ret = $this->cms_content_comment_sort->set(array($cates['mid'], $id), array(
            'cid' => $cid,
            'comments' => $comments,
            'lastdate' => $_ENV['_time'],
        ));
        if(!$ret) {
            $this->message(0, lang('commented_failed'));
        }

		// hook comment_control_post_after.php

		$this->message(1, lang('commented_successfully'));
	}

	// 获取评论JSON
	public function json() {
		$cid = (int)R('cid');
		$id = (int)R('id');

		$commentid = (int)R('commentid');
		$orderway = isset($_GET['orderway']) && $_GET['orderway'] == 1 ? 1 : -1;
		$pagenum = empty($_GET['pagenum']) ? 20 : max(1, (int)$_GET['pagenum']);
		$dateformat = empty($_GET['dateformat']) ? 'Y-m-d H:i:s' : decrypt($_GET['dateformat']);
		$humandate = isset($_GET['humandate']) ? ($_GET['humandate'] == 1 ? 1 : 0) : 1;

		if(empty($cid) || empty($id) || empty($commentid)) $this->message(0, lang('data_error'));

		$cates = $this->category->get_cache($cid);
		empty($cates) && $this->message(0, lang('data_error'));

		// 获取评论列表
		$key = $orderway == 1 ? '>' : '<';
		$where = array('mid' => $cates['mid'], 'id' => $id, 'commentid' => array($key => $commentid));
		$ret = array();
		$ret['list_arr'] = $this->cms_content_comment->find_fetch($where, array('commentid' => $orderway), 0, $pagenum);
		foreach($ret['list_arr'] as &$v) {
			$this->cms_content_comment->format($v, $dateformat, $humandate);
		}

		$end_arr = end($ret['list_arr']);
		$commentid = $end_arr['commentid'];
		$orderway = max(0, $orderway);
		$dateformat = base64_encode($dateformat);
		$ret['next_url'] = $this->_cfg['webdir']."index.php?comment-json-cid-$cid-id-$id-commentid-$commentid-orderway-$orderway-pagenum-$pagenum-dateformat-".encrypt($dateformat)."-humandate-$humandate-ajax-1";
		$ret['isnext'] = count($ret['list_arr']) < $pagenum ? 0 : 1;

		echo json_encode($ret);
		exit;
	}

	//生成验证码
    public function vcode(){
        $vcode = new vcode();
        $name = R('name','G');
        // hook comment_control_vcode_after.php
        return $vcode->get_vcode($name);
    }

	// hook comment_control_after.php
}
