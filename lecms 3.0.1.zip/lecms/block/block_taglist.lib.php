<?php
defined('ROOT_PATH') || exit;

/**
 * 标签列表模块
 * @param int mid 模型ID
 * @param string orderby 排序方式 (参数有 tagid count)
 * @param int orderway 降序(-1),升序(1)
 * @param int start 开始位置
 * @param int limit 显示几条标签
 * @return array
 */
function block_taglist($conf) {
	global $run;

	// hook block_taglist_before.php
    $mid = isset($conf['mid']) ? intval($conf['mid']) : (isset($_GET['mid']) ? intval($_GET['mid']) : 2);
	$table = isset($run->_cfg['table_arr'][$mid]) ? $run->_cfg['table_arr'][$mid] : 'article';
	$orderby = isset($conf['orderby']) && in_array($conf['orderby'], array('tagid', 'count')) ? $conf['orderby'] : 'count';
	$orderway = isset($conf['orderway']) && $conf['orderway'] == 1 ? 1 : -1;
    $start = _int($conf, 'start', 0);
	$limit = isset($conf['limit']) ? (int)$conf['limit'] : 10;

	$run->cms_content_tag->table = 'cms_'.$table.'_tag';
	$list_arr = $run->cms_content_tag->find_fetch(array(), array($orderby => $orderway), $start, $limit);
    $xuhao = 1;
	foreach($list_arr as &$v) {
		$v['url'] = $run->cms_content->tag_url($mid, $v['name'], $v['tagid']);
        if( empty($v['pic']) ){
            $v['pic'] = $run->_cfg['webdir'].'static/img/nopic.gif';
        }else{
            if( substr($v['pic'], 0, 2) != '//' && substr($v['pic'], 0, 4) != 'http' ){ //不是外链图片
                $v['pic'] = $run->_cfg['webdir'].$v['pic'];
            }
        }
        $v['xuhao'] = $xuhao;
        $xuhao++;
	}

	// hook block_taglist_after.php

	return array('list'=>$list_arr);
}
