<?php
defined('ROOT_PATH') || exit;

/**
 * 导航模块 (最多支持两级)
 * @param int mobile 移动端导航
 * @param int showcate 是否显示分类信息
 * @return array
 */
function block_navigate($conf) {
	global $run;
    $mobile = isset($conf['mobile']) ? intval($conf['mobile']) : 0;
    $showcate = _int($conf, 'showcate', 0);

	// hook block_navigate_before.php

    if($mobile){
        $field = 'navigate_mobile';
    }else{
        $field = 'navigate';
    }

    if($showcate){
        $allcategorys = $run->category->get_category_db();
    }else{
        $allcategorys = array();
    }

	$nav_arr = $run->kv->xget($field);
	foreach($nav_arr as &$v) {
		if($v['cid'] > 0) {
			$v['url'] = $run->category->category_url($v['cid'], $v['alias']);
		}
        if($v['cid'] > 0 && $allcategorys){
            $v['category'] = isset($allcategorys[$v['cid']]) ? $allcategorys[$v['cid']] : array();
            $run->category->format($v['category']);
        }else{
            $v['category'] = array();
        }

		if(!empty($v['son'])) {
			foreach($v['son'] as &$v2) {
				if($v2['cid'] > 0) {
					$v2['url'] = $run->category->category_url($v2['cid'], $v2['alias']);
				}
                if($v2['cid'] > 0 && $allcategorys){
                    $v2['category'] = isset($allcategorys[$v2['cid']]) ? $allcategorys[$v2['cid']] : array();
                    $run->category->format($v2['category']);
                }else{
                    $v2['category'] = array();
                }
			}
		}
	}

	// hook block_navigate_after.php

	return $nav_arr;
}
