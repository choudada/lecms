<?php
defined('ROOT_PATH') || exit;

/**
 * 根据ID或者ID串读取内容列表模块
 * @param int id 内容ID
 * @param string ids 内容ID串 (必须是同一个模型下的)
 * @param int mid 模型ID (默认为2)
 * @param string dateformat 时间格式
 * @param int titlenum 标题长度
 * @param int intronum 简介长度
 * @param int showcate 是否显示分类信息
 * @param int showviews 是否内容浏览量信息
 * @param int field_format 是否格式化主表自定义字段内容（主要是单选框、多选框、下拉框、图集等）
 * @return array
 */
function block_list_by_id($conf) {
	global $run;

	// hook block_list_by_id_before.php

    $id = _int($conf, 'id', 0);   // 优先级高于ids
    $ids = empty($conf['ids']) ? '' : $conf['ids'];    //多个id 用,隔开
	$mid = _int($conf, 'mid', 2);
	$dateformat = empty($conf['dateformat']) ? 'Y-m-d H:i:s' : $conf['dateformat'];
	$titlenum = _int($conf, 'titlenum');
	$intronum = _int($conf, 'intronum');
    $showcate = _int($conf, 'showcate', 0);
    $showviews = _int($conf, 'showviews', 0);
    $field_format = _int($conf, 'field_format', 0);

    $table_arr = &$run->_cfg['table_arr'];
    $table = isset($table_arr[$mid]) ? $table_arr[$mid] : 'article';

    $run->cms_content->table = 'cms_'.$table;

    if($showcate){
        $allcategorys = $run->category->get_category_db();
    }else{
        $allcategorys = array();
    }

    if($id){
        $data = $run->cms_content->read($id);
        if( empty($data) ){
            return array();
        }

        if($showviews){
            $run->cms_content_views->table = 'cms_'.$table.'_views';
            $views_arr = $run->cms_content_views->get($id);
        }else{
            $views_arr = array();
        }

        $run->cms_content->format($data, $mid, $dateformat, $titlenum, $intronum, $field_format);
        if($showcate && $allcategorys){
            $cate = isset($allcategorys[$data['cid']]) ? $allcategorys[$data['cid']] : array();
            if($cate){
                $data['cate_name'] = $cate['name'];
                $data['cate_url'] = $run->category->category_url($cate['cid'], $cate['alias']);
            }else{
                $data['cate_name'] = 'No Title';
                $data['cate_url'] = 'javascript:;';
            }
        }

        if($showviews && $views_arr){
            $data['views'] = isset($views_arr['views']) ? $views_arr['views'] : 0;
        }

        // hook block_list_by_id_after.php

        return $data;
    }elseif ($ids){
        $keys = explode(',', $ids);

        if($showviews){
            $run->cms_content_views->table = 'cms_'.$table.'_views';
            $views_list_arr = $run->cms_content_views->mget($keys);
            $views_key = 'cms_'.$table.'_views-id-';
        }else{
            $views_key = '';
            $views_list_arr = array();
        }

        $list_arr = $run->cms_content->mget($keys);
        $xuhao = 1;
        foreach($list_arr as &$v) {
            $run->cms_content->format($v, $mid, $dateformat, $titlenum, $intronum, $field_format);
            if($showcate && $allcategorys){
                $cate = isset($allcategorys[$v['cid']]) ? $allcategorys[$v['cid']] : array();
                if($cate){
                    $v['cate_name'] = $cate['name'];
                    $v['cate_url'] = $run->category->category_url($cate['cid'], $cate['alias']);
                }else{
                    $v['cate_name'] = 'No Title';
                    $v['cate_url'] = 'javascript:;';
                }
            }
            if($showviews && $views_list_arr){
                $v['views'] = isset($views_list_arr[$views_key.$v['id']]) ? $views_list_arr[$views_key.$v['id']]['views'] : 0;
            }
            $v['xuhao'] = $xuhao;
            $xuhao++;
        }

        // hook block_list_by_id_after.php

        return array('list'=> $list_arr);
    }else{
        return array('list'=> array());
    }
}
