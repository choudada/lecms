<?php
defined('ROOT_PATH') || exit;

/**
 * 指定时间内的内容数量统计
 * @param int mid 模型ID 必填 默认为 2
 * @param string type 时间类型   今天(today) 昨天(yesterday) 本周(week) 本月(month) 本年(year) 所有(all)
 * @param int life 缓存时间
 * @return int
 */
function block_content_total_by_date($conf) {
	global $run;

	// hook block_content_total_by_date_before.php

    $mid = _int($conf, 'mid', 2);
    $table_arr = &$run->_cfg['table_arr'];
    $table = isset($table_arr[$mid]) ? $table_arr[$mid] : '';

    if( empty($table) ){
        return  0;
    }

    $type = isset($conf['type']) ? $conf['type'] : 'all';
    $life = _int($conf, 'life', 0);

    //缓存
    $cache_key = 'content_total_by_date_'.$mid.'_'.$type;
    $cache_data = $run->kv->get($cache_key);
    if($life && $cache_data){
        return (int)$cache_data;
    }

    $run->cms_content->table = 'cms_'.$table;
    $total = 0;
	switch($type) {
		case 'all':
            $total = $run->cms_content->count();
			break;
		case 'today':
            $starttime = mktime(0,0,0,date('m'),date('d'),date('Y'));
            $where = array('dateline'=>array('>'=>$starttime));
            $total = $run->cms_content->find_count($where);
            break;
		case 'yesterday':
            $starttime = mktime(0,0,0,date('m'),date('d')-1,date('Y'));
            $endtime = mktime(0,0,0,date('m'),date('d'),date('Y'))-1;

            $where = array('dateline'=>array('>'=>$starttime, '<='=>$endtime));
            $total = $run->cms_content->find_count($where);
            break;
        case 'week':
            //$starttime = mktime(0,0,0,date('m'),date('d')-date('w')+1,date('y')); //这个按周日开始

            $starttime = mktime(0, 0, 0, date('m'), (date('d') - (date('w')>0 ? date('w') : 7) + 1), date('Y'));    //周一开始

            $where = array('dateline'=>array('>'=>$starttime));
            $total = $run->cms_content->find_count($where);
            break;
		case 'month':
            $starttime = mktime(0,0,0,date('m'),1,date('Y'));

            $where = array('dateline'=>array('>'=>$starttime));
            $total = $run->cms_content->find_count($where);
            break;
        case 'year':
            $starttime  = strtotime(date('Y',time())."-1"."-1");

            $where = array('dateline'=>array('>'=>$starttime));
            $total = $run->cms_content->find_count($where);
            break;
	}

    // hook block_content_total_by_date_type_after.php

    if($life){
        $run->kv->set($cache_key, $total, $life);
    }

	// hook block_content_total_by_date_after.php

	return $total;
}
