<?php
defined('ROOT_PATH') || exit;

/**
 * SQL模块
 * @param string sql SQL语句
 * @return array
 */
function block_sql($conf) {
	global $run;
    $sql = empty($conf['sql']) ? '' : $conf['sql'];
    if(empty($sql)) return array();

	// hook block_sql_before.php

    if( strpos($sql, '@#') ) {    //使用表前缀
        $table_prefix = $_ENV['_config']['db']['master']['tablepre'];
        $sql = str_replace('@#', $table_prefix, $sql);
    }

    $list_arr = $run->db->fetch_all($sql);

	// hook block_sql_after.php

	return array('list'=> $list_arr);
}
