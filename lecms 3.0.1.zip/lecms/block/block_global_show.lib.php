<?php
defined('ROOT_PATH') || exit;

/**
 * 内容页模块
 * @param string dateformat 时间格式
 * @param int show_prev_next 显示上下翻页
 * @param int field_format 是否格式化主表自定义字段内容（主要是单选框、多选框、下拉框、图集等）
 * @return array
 */
function block_global_show($conf) {
	global $run, $_show;

	// hook block_global_show_before.php

	$dateformat = empty($conf['dateformat']) ? 'Y-m-d H:i:s' : $conf['dateformat'];
	$show_prev_next = isset($conf['show_prev_next']) && (int)$conf['show_prev_next'] ? true : false;
    $field_format = _int($conf, 'field_format', 0);

	// 排除单页模型
	$mid = &$run->_var['mid'];
	if($mid == 1) return FALSE;

	// 初始模型表名
	$run->cms_content_data->table = 'cms_'.$run->_var['table'].'_data';

	// 格式化
	$run->cms_content->format($_show, $mid, $dateformat, 0, 0, $field_format);

	// 合并大数据字段
	$id = &$_show['id'];
	$_show['comment_url'] = $run->cms_content->comment_url($run->_var['cid'], $id);

	$data = $run->cms_content_data->read($id);
	if($data){
        if($field_format && plugin_is_enable('models_filed')){
            $models_field = $run->models_field->user_defined_field($mid);
            $run->models_field->field_val_format($models_field, $data, 0);
        }
        $_show += $data;
    }

	//更新浏览量
    $run->cms_content_views->table = 'cms_'.$run->_var['table'].'_views';
    $views_data = $run->cms_content_views->get($id);
    if($views_data){
        $_show['views'] = $views_data['views']+1;
        $run->cms_content_views->set($id, array('views'=>$_show['views'],'cid'=>$_show['cid']));
    }else{
        $_show['views'] = 1;
        $run->cms_content_views->set($id, array('views'=>1,'cid'=>$_show['cid']));
    }

    // hook block_global_show_center.php

	// 显示上下翻页 (大数据站点建议关闭)
	if($show_prev_next) {
		// 上一页
		$_show['prev'] = $run->cms_content->find_fetch(array('cid' => $run->_var['cid'], 'id'=>array('<'=> $id)), array('id'=>-1), 0 , 1);
		$_show['prev'] = current($_show['prev']);
		$run->cms_content->format($_show['prev'], $mid, $dateformat);

		// 下一页
		$_show['next'] = $run->cms_content->find_fetch(array('cid' => $run->_var['cid'], 'id'=>array('>'=> $id)), array('id'=>1), 0 , 1);
		$_show['next'] = current($_show['next']);
		$run->cms_content->format($_show['next'], $mid, $dateformat);
	}

	// hook block_global_show_after.php

	return $_show;
}
