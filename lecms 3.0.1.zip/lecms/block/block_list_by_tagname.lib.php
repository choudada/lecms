<?php
defined('ROOT_PATH') || exit;

/**
 * 根据标签名读取内容列表模块
 * @param int name 标签名
 * @param int mid 模型ID (默认为2)
 * @param string dateformat 时间格式
 * @param int titlenum 标题长度
 * @param int intronum 简介长度
 * @param int orderway 降序(-1),升序(1)
 * @param int start 开始位置
 * @param int limit 总共显示几条内容列表
 * @param int showcate 是否显示分类信息
 * @param int showviews 是否内容浏览量信息
 * @return array
 */
function block_list_by_tagname($conf) {
	global $run;

	// hook block_list_by_tagname_before.php

    $tagname = empty($conf['name']) ? '' : $conf['name'];
	$mid = _int($conf, 'mid', 2);
	$dateformat = empty($conf['dateformat']) ? 'Y-m-d H:i:s' : $conf['dateformat'];
	$titlenum = _int($conf, 'titlenum');
	$intronum = _int($conf, 'intronum');
	$orderway = isset($conf['orderway']) && $conf['orderway'] == 1 ? 1 : -1;
	$start = _int($conf, 'start');
	$limit = _int($conf, 'limit', 10);
    $showcate = _int($conf, 'showcate', 0);
    $showviews = _int($conf, 'showviews', 0);

    $table_arr = &$run->_cfg['table_arr'];
    $table = isset($table_arr[$mid]) ? $table_arr[$mid] : 'article';

    $run->cms_content_tag->table = 'cms_'.$table.'_tag';
    $run->cms_content_tag_data->table = 'cms_'.$table.'_tag_data';
    $run->cms_content->table = 'cms_'.$table;

    //获取标签信息
    $tagdata = $run->cms_content_tag->find_fetch(array('name'=>$tagname), array(), 0, 1);
    if( empty($tagdata) ){
        return array('tag_name'=> $tagname, 'tag_url'=> 'javascript:;', 'list'=> array());
    }else{
        $tagdata = current($tagdata);
    }
    $tagid = $tagdata['tagid'];

    $tag_arr = $run->cms_content_tag_data->find_fetch(array('tagid'=>$tagid), array('id'=>$orderway), $start, $limit);
    $keys = array();
    foreach($tag_arr as $v) {
        $keys[] = $v['id'];
    }

    $tag_url = $run->cms_content->tag_url($mid, $tagdata['name'], $tagid);

    if( empty($keys) ){
        return array('tag_name'=> $tagname, 'tag_url'=> $tag_url, 'list'=> array());
    }

    if($showcate){
        $allcategorys = $run->category->get_category_db();
    }else{
        $allcategorys = array();
    }

    if($showviews){
        $run->cms_content_views->table = 'cms_'.$table.'_views';
        $views_list_arr = $run->cms_content_views->mget($keys);
        $views_key = 'cms_'.$table.'_views-id-';
    }else{
        $views_key = '';
        $views_list_arr = array();
    }

    $list_arr = $run->cms_content->mget($keys);
    $xuhao = 1;
    foreach($list_arr as &$v) {
        $run->cms_content->format($v, $mid, $dateformat, $titlenum, $intronum);
        if($showcate && $allcategorys){
            $cate = isset($allcategorys[$v['cid']]) ? $allcategorys[$v['cid']] : array();
            if($cate){
                $v['cate_name'] = $cate['name'];
                $v['cate_url'] = $run->category->category_url($cate['cid'], $cate['alias']);
            }else{
                $v['cate_name'] = 'No Title';
                $v['cate_url'] = 'javascript:;';
            }
        }
        if($showviews && $views_list_arr){
            $v['views'] = isset($views_list_arr[$views_key.$v['id']]) ? $views_list_arr[$views_key.$v['id']]['views'] : 0;
        }
        $v['xuhao'] = $xuhao;
        $xuhao++;
    }

    // hook block_list_by_tagname_after.php

    return array('tag_name'=> $tagname, 'tag_url'=> $tag_url, 'list'=> $list_arr);
}
