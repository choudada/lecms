<?php
defined('ROOT_PATH') || exit;

/**
 * 标签列表页模块（分页）
 * @param int mid 模型ID，优先级高于 REQUEST里面的
 * @param int pagenum 每页显示条数
 * @param string orderby 排序方式 (参数有 tagid count)
 * @param int orderway 降序(-1),升序(1)
 * @param int pageoffset 分页显示偏移量
 * @param int showmaxpage 最多显示多少页
 * @return array
 */
function block_global_tag($conf) {
	global $run;

	// hook block_global_tag_before.php
    if( isset($conf['mid']) ){
        $mid = _int($conf, 'mid', 2);
    }else{
        $mid = max(2, (int)R('mid', 'R'));
    }
	$pagenum = empty($conf['pagenum']) ? 20 : max(1, (int)$conf['pagenum']);
    $orderby = isset($conf['orderby']) && in_array($conf['orderby'], array('tagid', 'count')) ? $conf['orderby'] : 'count';
	$orderway = isset($conf['orderway']) && $conf['orderway'] == 1 ? 1 : -1;
    $pageoffset = _int($conf, 'pageoffset', 5);
    $showmaxpage = _int($conf, 'showmaxpage', 0);

    $table_arr = &$run->_cfg['table_arr'];
    $table = isset($table_arr[$mid]) ? $table_arr[$mid] : 'article';
    // 初始模型表名
    $run->cms_content_tag->table = 'cms_'.$table.'_tag';

    $where = $extra = array();
    // hook block_global_tag_where_after.php

	// 初始分页
	if($where){
        $total = $run->cms_content_tag->find_count($where);
    }else{
        $total = $run->cms_content_tag->count();
    }
	$maxpage = max(1, ceil($total/$pagenum));
    if($showmaxpage && $maxpage > $showmaxpage){
        $maxpage = $showmaxpage;
    }
	$page = min($maxpage, max(1, intval(R('page'))));
	$pages = pages($page, $maxpage, $run->cms_content->tag_all_url($mid, TRUE, $extra), $pageoffset);

    $list_arr = $run->cms_content_tag->list_arr($where, $orderby, $orderway, ($page-1)*$pagenum, $pagenum, $total);
    $xuhao = 1;
    foreach($list_arr as &$v) {
        $v['url'] = $run->cms_content->tag_url($mid, $v['name'], $v['tagid']);
        if( empty($v['pic']) ){
            $v['pic'] = $run->_cfg['webdir'].'static/img/nopic.gif';
        }else{
            if( substr($v['pic'], 0, 2) != '//' && substr($v['pic'], 0, 4) != 'http' ){ //不是外链图片
                $v['pic'] = $run->_cfg['webdir'].$v['pic'];
            }
        }
        $v['xuhao'] = $xuhao;
        $xuhao++;
    }

    $data = array('total'=> $total, 'pages'=> $pages, 'list'=>$list_arr, 'title'=>lang('all'));

	// hook block_global_tag_after.php

	return $data;
}
