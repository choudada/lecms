<?php
return array (
  'editor_sd' =>
  array (
    'enable' => 1,
  ),
);
